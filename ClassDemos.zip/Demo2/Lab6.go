package main

import (
	"fmt"
	"time"
	"math/rand"
)

var (
	WIN_LIMIT   = 1000
	WINNER_FLAG = false
)

func car(number int) {
	for i := 0; i < WIN_LIMIT; i++ {
		r:=rand.Intn(10)
		time.Sleep(time.Duration(r) * time.Millisecond)
		if WINNER_FLAG == true {
			fmt.Println("Stopping the car", number)
			return
		}
	}
	WINNER_FLAG = true
	fmt.Printf("Car %d Won the game\n", number)
}

func main() {
	go car(1)
	go car(2)
	go car(3)
	s := ""
	fmt.Scanln(&s)
}
