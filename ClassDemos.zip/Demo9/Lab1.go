package main

import (
	"fmt"
	"strconv"
	"errors"
)
func Add(n1, n2 int ) int{
	return n1+n2
}

func Divide(n1, n2 string ) (int, error){
	no1,err := strconv.Atoi(n1)
	if err != nil{
		return 0,  errors.New("InvalidArg1")
	}
	no2,err := strconv.Atoi(n2)
	if err != nil{
		return 0, errors.New("InvalidArg2")
	}
	if no2 == 0 {
		return 0, errors.New("Arg2 is zero")
	}
	return no1/no2, nil
}

func main(){
	fmt.Println("Add = " , Add(10,10))
	ans, err:=Divide("100","10")
	fmt.Println(ans, err)
	ans, err=Divide("aa","10")
	fmt.Println(ans, err)
	ans, err=Divide("100","a")
	fmt.Println(ans, err)
	ans, err=Divide("100","0")
	fmt.Println(ans, err)
}