package main
import "testing"
import "fmt"

func BenchmarkAdd(b *testing.B) {
	fmt.Println(b.N)
    for  i:=0;i<b.N;i++  {
        Add(100,500)
    }
}
func TestAdd(t *testing.T) {
    got := Add(10, 20)
    if got != 30 {
        t.Errorf("Add(10,20) = %d; want 30", got)
    }
}

func TestDivide1(t *testing.T) {
    got := Divide("100", "20")
    if got != 5 {
        t.Errorf("Divide(100,20) = %d; want 5", got)
    }
}
/*
func TestDivide2(t *testing.T) {
	// recover function -> fail only if recover function does not have error 

    got := Divide("100", "0")
	// no problem if error is thrown
    if got != 0 {
        t.Errorf("Divide(100,20) = %d; want 0", got)
    }
}
	*/
	