package dblib
import(
	"database/sql"
	_ "github.com/go-sql-driver/mysql"
	"strconv"
	"fmt"
)
// Dept represents the structure of a department
type Dept struct {
    Deptno int    `json:"deptno"`
    Dname  string `json:"dname"`
    Loc    string `json:"loc"`
}
func Add(dept Dept){
	db, _ := sql.Open("mysql", "admin:MyPassword@tcp(mydb.ctu244mmwtr1.us-east-1.rds.amazonaws.com:3306)/mydatabase1")
	defer db.Close()
	sqlstring:= "insert into dept values (" + strconv.Itoa(dept.Deptno) +",'" + dept.Dname + "','" + dept.Loc+ "')"
	fmt.Println("Add-Dept  " , sqlstring)
	result, _:= db.Exec(sqlstring)
	rows,_:=result.RowsAffected()
	fmt.Println("Rows affected " , rows)
}
