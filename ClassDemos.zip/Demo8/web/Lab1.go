package main
import (
    "encoding/json"
    "fmt"
    "net/http"
    "dblib"
)
type DeptHandler struct{} 
// ServeHTTP handles GET and POST requests
func (my *DeptHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
    w.Header().Set("Content-Type", "application/json")
    switch r.Method {
    case "GET":
        // Marshal the slice of departments to JSON
        /*
        data, err := json.Marshal(departments)
        if err != nil {
            http.Error(w, err.Error(), http.StatusInternalServerError)
            return
        }*/
        // Write the JSON data to the response
        w.WriteHeader(http.StatusOK)
        
 
    case "POST":
        // Create a new Dept instance
        var newDept dblib.Dept
 
        // Decode the JSON request body into the newDept
        err := json.NewDecoder(r.Body).Decode(&newDept)
        if err != nil {
            http.Error(w, err.Error(), http.StatusBadRequest)
            return
        }
 
        // Add the new department to db 
        dblib.Add(newDept)
 
        // Log the current departments slice
        fmt.Println("Updated departments in db")
 
        // Send a success response
        w.WriteHeader(http.StatusCreated)
        json.NewEncoder(w).Encode(newDept)
    }
}
 
func main() {
    http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
        fmt.Fprintf(w, "<h1>Hello World</h1>")
    })
 
    // Dept handler
    http.Handle("/dept", new(DeptHandler))
 
    // Start the server
    fmt.Println("Starting server on :8080")
    http.ListenAndServe(":8080", nil)
}
 