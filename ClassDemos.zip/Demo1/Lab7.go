package main
import (
	"fmt"
)
func main(){
	defer func(){
			r:=recover()
			fmt.Println("recover invoked in defer function " , r)
		}()
	no1,no2 := 0,0
	fmt.Println("Enter a number")
	cnt, err:=fmt.Scan(&no2)
	fmt.Println("Count =",cnt , " and Error = ", err )

	fmt.Println("Ans = ", no1/no2)
	
	fmt.Println("after divide by zero")
}