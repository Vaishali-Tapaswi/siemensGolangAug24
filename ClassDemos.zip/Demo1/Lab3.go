package main

import "fmt"

func main() {
	x,y:=600,500
	sum, sub := calc(x,y)
	fmt.Println("Sum = ", sum, "\nSub = ", sub)
}