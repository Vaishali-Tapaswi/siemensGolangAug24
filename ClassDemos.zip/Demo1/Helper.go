package main

import "fmt"
func calc(a, b int)(int, int ){
	fmt.Println("Helper1.go - calc function ")
	return a+b, a-b;
}

/*
func add(a, b int ) int{
	fmt.Println("Helper1.go - add function ")
	return a+b
}
func sub(a, b int ) int{
	fmt.Println("Helper1.go - sub function ")
	return a-b
}
*/
