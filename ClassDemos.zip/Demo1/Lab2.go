package main
import (
	"fmt"
	"os"
	"strconv"
)
func main(){
	 a,b := "aa",20
	
	fmt.Println(os.Args)
	fmt.Println("Hi", a, b)
	no1, _ := strconv.Atoi(os.Args[1])
	no2, _ := strconv.Atoi(os.Args[2])
	fmt.Println("Total = ", no1+no2)

}