package main

import (
	"database/sql"
	_ "github.com/go-sql-driver/mysql"
	"fmt"
	)
func main(){
	
	db, err := sql.Open("mysql", "admin:MyPassword@tcp(mydb.ctu244mmwtr1.us-east-1.rds.amazonaws.com:3306)/mydatabase1")
	fmt.Println(db, err)
	defer db.Close()
	result, err:= db.Exec("insert into dept values (2,'Fin', 'Hyd')")
	fmt.Println(result, err)
	rows,err:=result.RowsAffected()
	fmt.Println(rows)
	}
