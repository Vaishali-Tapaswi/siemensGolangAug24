package main
import (
	"fmt"
	"mypack"
)
func main(){
	fmt.Println("in main ")
	ans := mypack.Add(1000,0400)
	fmt.Println("Ans = "  , ans)
}