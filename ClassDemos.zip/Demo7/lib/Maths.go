package mypack
import "fmt"
func Add(n1, n2 int) int{
	fmt.Println("mypack - add method invoked with " , n1 , n2)
	return n1+n2
}
